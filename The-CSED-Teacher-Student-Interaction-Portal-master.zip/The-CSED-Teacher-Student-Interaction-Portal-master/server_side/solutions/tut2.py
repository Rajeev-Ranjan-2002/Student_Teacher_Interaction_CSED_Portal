def hello():
    print('hare krishna')
#if __name__ == '__main__':
    print('hare rama')
